import java.util.TreeMap
import java.util.TreeSet

private fun nextLine() = readLine()!!
private fun nextInt() = nextLine().toInt()
private fun nextToks() = nextLine().split(" ")
private fun nextInts() = nextToks().map{it.toInt()}

fun TreeMap<Int,Int>.inc(k: Int, v: Int = 1) 
    = this.put(k,v+(this.get(k)?:0))
fun TreeMap<Int,Int>.dec(k: Int, v: Int = 1) 
    = this.put(k,-v+(this.get(k)?:0))
fun abs(x: Int): Int = if (x<0) -x else x

fun dfs(diff: TreeMap<Int,Int>, cand: ArrayList<Int>, R: Int,
        ans: MutableSet<List<Int>>) {
    // If no more difference, we've found a solution 
    if(diff.size == 0) {
        ans.add(cand.sorted())
        return
    }
    val last = diff.lastKey()!! // should not crash
    if (diff[last]!!>2) return  // backtrack if 3+ maxima exist
    for (target in listOf(last, R-last)) { 
        // at most 2 positions to try
        var pos = TreeMap<Int,Int>()
        cand.map{pos.inc(abs(target-it))}
        if (pos.all{(k,v) -> v <= (diff[k]?:0)}) {
            pos.forEach{(k,v) -> 
                diff.dec(k,v)
                if (diff[k] == 0) diff.remove(k)
            }
            cand.add(target)
            dfs(diff, cand, R, ans)
            cand.removeAt(cand.size-1)
            pos.forEach{(k,v) -> diff.inc(k,v)}
        }
        // If 2 maxima, we don't need to branch
        if(2==diff[last]!!) break
    }
}

fun main() {
    val n = nextInt()
    val diff = TreeMap<Int,Int>()
    nextInts().forEach{diff.put(it,1+(diff.get(it)?:0))}
    val last = diff.lastKey()!! // should not crash
    if (diff[last]!!>1) { // no solution if there are 2+ maxima.
        println(0)
        return
    }
    diff.remove(last)
    var ans = HashSet<List<Int>>()
    dfs(diff,ArrayList<Int>(listOf(0, last)),last,ans)
    println("${ans.size}")
    var cand = ArrayList<List<Int>>(ans)
    cand.sortWith(Comparator<List<Int>>{x, y -> 
        var ret = 0
        for (i in 0 until n)
            if (x[i] != y[i]) {
                ret = x[i]-y[i]
                break
            }
        ret
    })
    for (s in cand)
        println(s.joinToString(" "))
}
