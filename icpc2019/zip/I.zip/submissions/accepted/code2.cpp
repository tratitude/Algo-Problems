#include <iostream>
#include <vector>
#include <map>
#include <algorithm>
#include <string>
#include <sstream>
#include <set>
#include <cassert>
using namespace std;

vector<int> seq;
map<int, int> spec_map;
decltype(spec_map.rbegin()) it_max;
vector<int> sol;
set<decltype(sol)> dic;
int total_length;

inline int get_max()    // return the max element in spec_map
{
    while ((it_max != spec_map.rend()) && (it_max->second ==0))
        ++it_max;
    if (it_max != spec_map.rend())
        return it_max->first;
    else
        return -1;
}

inline bool test_inclusion(int k)   // test whether k can be added to sol; it so, remove \delta(k)
{
int d;
bool ok=true;
decltype(sol.cbegin()) it;

    for (it=sol.cbegin(); it!=sol.cend(); ++it) {
        d=abs(*it-k);
        if (spec_map.count(d)>0 && spec_map[d]>0)
            --spec_map[d];
        else { ok=false; break; }
    }
    if (!ok)        // restore failed trial
        for (auto it2=sol.cbegin(); it2!=it; ++it2)
            ++spec_map[abs(*it2-k)];
    return ok;
}

inline void restore_test(int k)
{
    for (auto it=sol.cbegin(); it!=sol.cend(); ++it)
        ++spec_map[abs(*it-k)];
}

int solver(int t)
{
int cnt=0;

    if (t<0) {        // find a solution
        decltype(sol) s=sol;
        sort(s.begin(),s.end());
        dic.insert(s);
        return 1;
    }
    if (test_inclusion(t)) {
        sol.push_back(t);
        auto it_max2=it_max;
        int k=get_max();

        // If spec_map[k]>=3, back track; if spec_map[k]=2, no branching is needed.
        if (k>0 && (spec_map[k]==1)) cnt=solver(total_length-k);  // left branch
        cnt+=solver(k);     // right branch
        it_max=it_max2;
        sol.pop_back();
        restore_test(t);
    }
    return cnt;
}

inline int read_1_int()     // make sure that this line has only one int
{
string str;
    getline(cin,str);
stringstream ss(str);
int n;
    ss >> n;
    assert(ss.rdstate()==ss.eofbit);
    return n;
}

int main()
{
int n, m;
string str;

    n=read_1_int();
    assert((n>1) && (n<=62));
    getline(cin,str);
    stringstream ss(str);
    while (ss >> m) {
        assert(0<m && m<1000);
        seq.push_back(m);
        if (spec_map.count(m)>0) ++spec_map[m];
        else spec_map[m]=1;
    }
    assert(seq.size()==n*(n-1)/2);
    it_max=spec_map.rbegin();
    sol.push_back(0);
    total_length=get_max();
    solver(total_length);
    cout << dic.size() << endl;
    for (const auto &s: dic)
        for (const auto p: s) {
            cout << p << ((p==total_length) ? "\n" : " ");
        }
    return 0;
}
