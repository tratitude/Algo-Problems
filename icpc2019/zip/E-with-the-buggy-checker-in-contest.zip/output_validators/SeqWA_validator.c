#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

int n,kk,L;
int seq[2000], pfx_sum[2001];

void wa()
{
	exit(43);
}

void accept()
{
	exit(42);
}

long long wrong_answer()
{
	int i,j,k;
	long long res, cur;

	res = cur = 0;
	k = -1;
	for(i=0;i<n;i++)
	{
		cur += seq[i];
		if( cur < 0 )
		{
			cur = 0;
			k = i;
		}
		if( 1LL*(i-k)*cur > res )
			res = 1LL*(i-k)*cur;
	}

	return res;
}

long long correct_answer()
{
	int i,j;
	long long k, res;

	pfx_sum[0] = 0;
	for(i=0;i<n;i++)
		pfx_sum[i+1] = pfx_sum[i] + seq[i];

	res = 0;
	for(i=0;i<n;i++)
	{
		for(j=i;j<n;j++)
		{
			k = 1LL * ( pfx_sum[j+1] - pfx_sum[i] ) * ( j - i + 1 );
			if( k > res )
				res = k;
		}
	}

	return res;
}

int main(int argc, char *argv[])
{
	int i,j,k;
	char tmp[1000];

	int T, inp[5][2];

	FILE *fptr;

	fptr = fopen(argv[1],"r");
	fscanf(fptr, "%d", &T);
	for(i=0;i<T;i++)
		fscanf(fptr, "%d%d", &inp[i][0], &inp[i][1]);
	fclose(fptr);

	for(i=0;i<T;i++)
	{
		if( scanf("%d", &n) != 1 )
			wa();
	
		if( inp[i][1] > 1999 )
		{
			if( n != -1 )
				wa();
			continue;
		}

		if( n < 1 || n >= 2000 || n < L )
			wa();

		for(j=0;j<n;j++)
			if( scanf("%d", &seq[j]) != 1 )
				wa();

		if( correct_answer() - wrong_answer() != inp[i][0] )
			wa();
	}

	if( scanf("%100s", tmp) == 1 )
		wa();

	accept();

	return 0;
}

