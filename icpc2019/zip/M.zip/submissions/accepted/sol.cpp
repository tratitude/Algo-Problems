
#include<iostream>
#include<map>
#include<algorithm>
#include<string>
#include<ctime>
using namespace std;
typedef long long int LL;
typedef map<LL,LL> MLL;
typedef map<LL,LL>::iterator MLLIT;
typedef map<LL,LL>::const_iterator MLLCIT;
ostream& operator<<(ostream&xout,MLL&mll){//return xout;
	for(MLLIT i=mll.begin();i!=mll.end();i++){
		xout<<"("<<(*i).first<<","<<(*i).second<<")";
	}
	return xout<<endl;
}
bool s_debug=1;
void debug(string s,MLL&mll){
	if(s_debug)cout<<s<<" "<<mll;
}

LL POW(LL b,LL n,LL d=0){	
	if(n==0)return 1;
	LL ans=POW(b,n/2);ans*=ans;if(d)ans%=d;
	if(n%2)ans*=b;if(d)ans%=d;
	return ans;
}
LL FacOrd(LL n,LL p){LL ans=0;while(n){ans+=n/=p;}return ans;}
LL ProCop(LL pm,LL p,LL m){
	if(p==2){
		if(m==1)return +1;
		if(m==2)return -1;
		return +1;
	}else{
		return -1;
	}
}
LL s_max=0;
LL FacCop(LL n,LL pm,LL p,LL m){LL ans=1;
  if(n<0){cout<<"ERROR:"<<n<<" "<<pm<<" "<<p<<" "<<m<<endl;}
	if(n>=pm){ans=POW(ProCop(pm,p,m),n/pm)*FacCop(n%pm,pm,p,m);ans+=pm;ans%=pm;}
	else{s_max=max(s_max,n);for(LL k=2;k<=n;k++){if(k%p)ans*=k;ans%=pm;}}//**************************	
	//if(s_debug)cout<<"n="<<n<<",cop="<<ans<<endl;
	return ans;
}
LL FacCopAll(LL n,LL pm,LL p,LL m){
  if(n<0){cout<<"ERRORALL:"<<n<<" "<<pm<<" "<<p<<" "<<m<<endl;}
	LL ans=FacCop(n,pm,p,m);
	while(n)ans=(ans*FacCop(n/=p,pm,p,m))%pm;
	return ans;	
}
void Factoring(LL n,map<LL,LL>&ans){
	for(LL d=2;n!=1;d++){while(n%d==0){ans[d]++;n/=d;}}
}
LL Inverse(LL C,LL D){
	LL n0=C,d0=D,r0=1;
	LL n1=1,d1=0,r1;
	LL n2=0,d2=1,r2;
	while(r0){LL q=(n0/d0);
		r0=(n0-q*d0);      if(r0){n0=d0;d0=r0;}
		r1=(n1-(q%D)*d1)%D;if(r0){n1=d1;d1=r1;}
		r2=(n2-(q%C)*d2)%C;if(r0){n2=d2;d2=r2;}
	}
	return (d1%D+D)%D;
}
LL CR(LL C,LL D){
	LL n0=C,d0=D,r0=1;
	LL n1=1,d1=0,r1;
	LL n2=0,d2=1,r2;
	while(r0){LL q=(n0/d0);
		r0=(n0-q*d0);      if(r0){n0=d0;d0=r0;}
		r1=(n1-(q%D)*d1)%D;if(r0){n1=d1;d1=r1;}
		r2=(n2-(q%C)*d2)%C;if(r0){n2=d2;d2=r2;}
	}
	//cout<<C<<" "<<D<<" "<<d2<<endl;
	return ((d2%C+C)%C)*D;
}
LL CR(const MLL&dr){if(dr.size()==1)return dr.begin()->second;
	LL n=1,ans=0;for(MLL::const_iterator i=dr.begin();i!=dr.end();i++)n*=(*i).first;	
	for(MLL::const_iterator i=dr.begin();i!=dr.end();i++){
		LL d=(*i).first,r=(*i).second;
		LL cr=CR(d,n/d);
		//cout<<d<<" "<<n/d<<" "<<cr<<" "<<r<<endl;
		ans+=cr*r;ans%=n;
	}
	return ans;
}
LL C(LL M,LL N,LL D){
	LL ans=1;
	N=min(N,M-N);
	for(LL k=1;k<=N;k++){
		ans*=M+1-k;ans/=k;
	}
	while(ans%D==0)ans/=D;
	return ans%D;
}
LL solve(LL M,LL N,LL D){
  if(s_debug)cout<<M<<" "<<N<<" "<<D<<endl;
  s_max=0;
	MLL pms;Factoring(D,pms);
	MLL prs,pos;
	for(MLLIT i=pms.begin();i!=pms.end();i++){LL p=(*i).first,m=(*i).second,pm=POW(p,m);
		pos[p]=FacOrd(M,p)-FacOrd(N,p)-FacOrd(M-N,p);
		LL MF=FacCopAll(M,pm,p,m);
		LL NF=FacCopAll(N,pm,p,m);  LL NI=Inverse(NF,pm);
		LL MN=FacCopAll(M-N,pm,p,m);LL MNI=Inverse(MN,pm);
		//if(s_debug)cout<<p<<" "<<MF<<" "<<NF<<" "<<MN<<" "<<NI<<" "<<MNI<<endl;
		LL ans=(((MF*Inverse(NF,pm))%pm)*Inverse(MN,pm))%pm;;
		ans+=pm;ans%=pm;
		prs[p]=ans;
	}
	debug("pms=",pms);
	//debug("pos=",pos);
	//debug("prs=",prs);
	for(MLLIT i=pms.begin();i!=pms.end();i++){LL p=(*i).first,m=(*i).second,pm=POW(p,m);
		for(MLLIT j=pos.begin();j!=pos.end();j++){LL q=(*j).first,n=(*j).second;if(p==q)continue;
			prs[p]*=Inverse(POW(q,n,pm),pm);prs[p]%=pm;
		}
	}
	//debug("prs=",prs);
	MLL crs;
	for(MLLIT i=pms.begin();i!=pms.end();i++){LL p=(*i).first,m=(*i).second,pm=POW(p,m);
		crs[pm]=prs[p];
	}
	LL ans=CR(crs);ans+=D;ans%=D;
	//debug("crs=",crs);
	if(s_debug)cout<<ans<<endl;
	LL mm=0x7fffffffffffff;
	for(MLLIT i=pms.begin();i!=pms.end();i++){LL p=(*i).first,m=(*i).second;
		mm=min(mm,pos[p]/m);
	}
	LL ans2=1;
	for(MLLIT i=pms.begin();i!=pms.end();i++){LL p=(*i).first,m=(*i).second;//,pm=POW(p,m);
		ans2*=POW(p,pos[p]-mm*m,D);ans2%=D;
	}
	//if(ans2==0)ans2=1;
  if(s_debug)cout<<"s_max="<<s_max<<endl;
	return (ans*ans2)%D;
}
LL RAND(){return ((rand()*32768LL+rand())&0x7fffffff)%2000000000;}
void tdcase(LL D=0){
  LL M=RAND()*RAND();
  LL N=M/(2+RAND()%3);
  if(D==0)D=RAND()%16000000;
  cout<<M<<" "<<N<<" "<<D<<endl;
}
void tdgen(){
  //cout<<10<<endl;
  tdcase(15999989);
  tdcase(15997109);
  tdcase(15997307);
  tdcase();
  tdcase();
  tdcase();
  tdcase();
  tdcase();
  tdcase();
  tdcase();
}
int main(int ac,char**av){
  if(ac==2){srand(time(0));
    if(string("tdgen")==av[1]){
      tdgen();
    }
    return 0;
  }
	s_debug=0;
	//cout<<FacCopAll(8,5,5,1)<<endl;
	//cout<<FacCopAll(7,8,2,3)<<endl;
	//return 0;
	LL M,N,D,m;	
	/*
	bool succ=true;	
	for(M=2;M<50&&succ;M++){for(N=0;N<=M/2&&succ;N++)
  {for(D=2;D<10000&&succ;D++){
		LL a=C(M,N,D);
		LL b=solve(M,N,D);
		if(a!=b){succ=false;cout<<"XXX "<<M<<" "<<N<<" "<<D<<" "<<a<<" "<<b<<endl;}		
	}}}
	cout<<"A"<<endl;
	return 0;
	//*/
  //cin>>M;
	while(cin>>M>>N>>D){	
		//cout<<C(M,N,D)<<" ";
		cout<<solve(M,N,D)<<endl;
	}
	return 0;
}
/*
LL fact(LL n,LL d){
	LL ans=1;for(LL k=1;k<=n;k++){
		ans*=k;if(ans%d==0)ans/=d;// NO ans%=d;
		if(ans<0)return -1;
	}
	return ans%d;
}
LL fact(LL n,LL pm,LL p,LL m){
	LL ans=1,r=0;
	for(LL k=1;k<=n;k++){
		LL u=k;while(u%p==0){u/=p;r++;r%=m;}
		ans*=u;
		ans%=pm;
	}
	while(r--){ans*=p;ans%=pm;}
	return ans;
}
LL Fac(LL n,LL pm,LL p,LL m){
	LL ord=FacOrd(n,p)%m;
	LL ans=FacCop(n,pm,p,m);
	while(n)ans=(ans*FacCop(n/=p,pm,p,m))%pm;
	ans*=POW(p,ord);ans=((ans%pm)+pm)%pm;	
	return ans;
}
LL Fact(LL n,LL pm,LL p,LL m);
LL FactCoPrime(LL n,LL pm,LL p,LL m){
	if(n>=pm)return FactCoPrime(n%pm,pm,p,m)*POW(-1,n/pm);
	LL ans=1;
	for(LL k=2;k<=n;k++){if(k%p)ans*=k;ans%=pm;}
	//cout<<"A"<<n<<" "<<ans<<endl;
	return ans;;
}
LL FactPrime(LL n,LL pm,LL p,LL m,LL& r){
	if(n==0)return 1;
	LL cop=1;//FactCoPrime(n/p,pm,p,m);
	LL u=n;r=0;while(u){r+=u/p;cop*=FactCoPrime(u/p,pm,p,m);cop%=pm;u/=p;}
	LL pri=POW(p,r%m);
	LL ans=cop*pri;while(ans&&ans%pm==0)ans/=pm;ans%=pm;
	//cout<<"B"<<n<<" "<<ans<<" "<<cop<<" "<<pri<<endl;
	return ans;
}
LL Fact(LL n,LL pm,LL p,LL m,LL&r){
	LL cop=FactCoPrime(n,pm,p,m);
	r=0;LL pri=FactPrime(n,pm,p,m,r);
	LL ans=cop*pri;while(ans&&ans%pm==0)ans/=pm;ans%=pm;
	//cout<<"C"<<n<<" "<<ans<<" "<<cop<<" "<<pri<<endl;
	if(ans<0)ans+=pm;
	return ans;
}
*/