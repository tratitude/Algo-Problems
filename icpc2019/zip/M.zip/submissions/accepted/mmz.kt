private fun nextLine() = readLine()!!
private fun nextToks() = nextLine().split(" ").filter{it!=""}
private fun nextLongs() = nextToks().map{it.toLong()}

// Factoring Long into [(prime, exp), ..., (prime, exp)]
fun factoring(n: Long): ArrayList<Pair<Long,Int>> {
    var remain = n.toInt()
    var ret = ArrayList<Pair<Long,Int>>()
    for (i in 2..4000) {
        if (remain % i == 0) {
            var cnt = 0
            while (remain % i == 0) {
                cnt += 1
                remain /= i
            }
            ret.add(Pair(i.toLong(), cnt))
        }
    }
    if (remain > 1) ret.add(Pair(remain.toLong(), 1))
    return ret
}

// To avoid MZ's error
fun Long.pow(k: Int) = this.toBigInteger().pow(k).toLong()
fun Long.modInverse(m: Long) = this.toBigInteger().modInverse(m.toBigInteger()).toLong()

fun factorial(n: Long, p: Long, k: Int): Pair<Long,Long> {
    // println("n: $n, p: $p, k: $k")
    if (n==0L) return Pair(1L, 0)
    val mod = p.pow(k)
    var subN = n / p
    var (subR, subE) = factorial(subN, p, k)
    // 4 and odd_p**k are normal, 2**k are special
    var rmd = if ((n/mod) % 2 == 0L || (p == 2L && k != 2)) 1L else mod-1
    for (i in 1L..n%mod)
        if (i % p != 0L)
            rmd = rmd * i % mod
    return Pair(subR * rmd % mod, subE + subN)
}

fun main() {
    val (n, m, d) = nextLongs()
    var factors = factoring(d)
    var results = ArrayList<LongArray>() // rmd, mod
    for ((p, x) in factors) { // p**x
        var (ar, ae) = factorial(n, p, x)
        var (br, be) = factorial(m, p, x)
        var (cr, ce) = factorial(n-m, p, x)
        val exp = ae - be - ce
        val mod = p.pow(x)
        var rmd = ar * br.modInverse(mod) % mod
        rmd = rmd * cr.modInverse(mod) % mod
        results.add(longArrayOf(rmd*p.pow((exp%x).toInt())%mod, mod, exp/x))
    }
    
    // Remove d**h
    val trailing = results.map{(_,_,x)->x}.min()?: 0L
    for (result in results) {
        result[2] -= trailing
        if (result[2] > 0) {
            result[0] = 0L
            continue
        }
        val q = (d / result[1]).modInverse(result[1])
        for (i in 1..trailing)
            result[0] = result[0] * q % result[1]
    }

    // Chinese remainder theorem
    val ans = results.reduce{(rem1, mod1,_), (rem2, mod2,_) ->
        val newMod = mod1 * mod2
        val part1 = rem1 * mod2 % newMod * mod2.modInverse(mod1) % newMod
        val part2 = rem2 * mod1 % newMod * mod1.modInverse(mod2) % newMod
        longArrayOf((part1+part2)%newMod, newMod, 0L)
    }
    println("${ans[0]}")
}
