private fun nextLine() = readLine()!!
private fun nextInt() = nextLine().toInt()
private fun nextToks() = nextLine().split(" ")
private fun nextLongs() = nextToks().map{it.toLong()}

data class Point(val first: Long, val second: Long)

operator fun Point.minus(p: Point) = 
    Point(this.first-p.first, this.second-p.second)
operator fun Point.plus(p: Point) = 
    Point(this.first+p.first, this.second+p.second)
operator fun Long.times(p: Point) =
    Point(this * p.first, this * p.second)
infix fun Point.cross(p: Point) = 
    this.first * p.second - this.second * p.first
infix fun Point.dot(p: Point) =
    this.first * p.first + this.second * p.second
fun ArrayList<Point>.pop() = this.removeAt(this.size-1)
fun ArrayList<Point>.lst(pos: Int) = this[this.size-pos]

fun invalid(p: Point, q: Point, r: Point) = (q-p) cross (r-q) <= 0

fun monotoneChain(pts: List<Point>): ArrayList<Point> {
    var ret = ArrayList<Point>()
    for (pt in pts) {
        while (ret.size > 1 && invalid(ret.lst(2), ret.lst(1), pt))
            ret.pop()
        ret.add(pt)
    }
    return ret
}

fun convexHull(rawPts: ArrayList<Point>): ArrayList<Point> {
    var pts = ArrayList<Point>()
    rawPts.sortWith(Comparator{p, q ->
        if (p.first == q.first) p.second.compareTo(q.second)
        else p.first.compareTo(q.first)
    })
    rawPts.forEachIndexed{i, pt ->
        if(i==0 || rawPts[i] != rawPts[i-1]) pts.add(pt)
    }
    var ret = monotoneChain(pts)
    ret.pop()
    pts.sortWith(Comparator{q, p ->
        if (p.first == q.first) p.second.compareTo(q.second)
        else p.first.compareTo(q.first)
    })
    ret.addAll(monotoneChain(pts))
    ret.pop()
    return ret
}

var m = 1
fun Int.next() = if (this == m-1) 0 else this + 1
fun Int.prev() = if (this == 0) m-1 else this - 1

fun solve() {
    val n = nextInt()
    var rawPts = ArrayList<Point>()
    for (i in 0 until n) {
        val (x, y) = nextLongs()
        rawPts.add(Point(x, y))
    }
    var cv = convexHull(rawPts)
    when (cv.size) {
        2 -> // degenerated as a line segment  
            println(0)
        3 -> { // convex hull is a triangle 
            val skipPts = cv.map{rawPts.indexOf(it)}
            val ans = rawPts.mapIndexed {i, pt ->
                if (skipPts.contains(i)) 0L
                else (cv[1]-cv[0] cross cv[2]-cv[0]) - minOf(
                        cv[0]-pt cross cv[1]-pt, 
                        cv[1]-pt cross cv[2]-pt,
                        cv[2]-pt cross cv[0]-pt)
            }.max()?:0L
            println("${ans/2}${if(ans%2==1L) ".5" else ""}")
        }
        else -> {// the answer will not be a degenerated triangle
            var ans = 0L
            m = cv.size
            for (i in 0 until m) {
                var p = i.next()
                var j = p.next()
                var q = j.next()
                var cp = cv[p]-cv[i] cross cv[j]-cv[i]
                var cq = cv[j]-cv[i] cross cv[q]-cv[i]
                while (j.next() != i) {
                    // phase 1: moving q
                    var cand = cv[j]-cv[i] cross cv[q.next()]-cv[i]
                    while (cq < cand) {
                        q = q.next()
                        cq = cand
                        cand = cv[j]-cv[i] cross cv[q.next()]-cv[i]
                    }
                    // phase 2: moving p
                    cand = cv[p.next()]-cv[i] cross cv[j]-cv[i]
                    while (cp < cand) {
                        p = p.next()
                        cp = cand
                        cand = cv[p]-cv[i] cross cv[j]-cv[i]
                    }
                    // phase 3: update and moving j
                    ans = maxOf(ans, cp + cq)
                    j = j.next()
                    cp = cv[p]-cv[i] cross cv[j]-cv[i]
                    cq = cv[j]-cv[i] cross cv[q]-cv[i]
                }
            }
            println("${ans/2}${if(ans%2==1L) ".5" else ""}")
        }
    }
}

fun main() = (1..nextInt()).forEach{solve()}
