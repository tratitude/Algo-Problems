#include<iostream>
#include<cmath>
#include<algorithm>
#include<climits>
#include<vector>
#include<algorithm>
#include<ctime>
typedef long long LL;
using namespace std;
class PT{public:
	LL mx,my;double md;
	PT(int x=0,int y=0):mx(x),my(y){}
	double abs()const{return sqrt(mx*mx+my*my);}
	LL abs2()const{return mx*mx+my*my;}
	bool operator==(PT b){return (mx==b.mx)&&(my==b.my);}
	PT operator-(PT b){return PT(mx-b.mx,my-b.my);}
	double cross(PT b){PT&a=(*this);return a.mx*b.my-a.my*b.mx;}
};
typedef vector<PT> ADT;
istream& operator>>(istream&xin,PT&pt){return xin>>pt.mx>>pt.my;}
ostream& operator<<(ostream&xout,PT&pt){return xout<<"("<<pt.mx<<","<<pt.my<<")";}
PT low(0,INT_MAX);
double angle(PT a){if(a==low)return -1;PT p=a-low;return acos(p.mx/p.abs());}
ostream& operator<<(ostream&xout,ADT&adt){xout<<adt.size();for(ADT::iterator p=adt.begin();p!=adt.end();p++){xout<<*p;}return xout<<endl;}
bool cmpangle(PT a,PT b){
	a=a-low;b=b-low;
	if(a.mx==0&&a.my==0)return true;
	if(b.mx==0&&b.my==0)return false;
	if(a.mx*b.my==b.mx*a.my)return a.abs2()<b.abs2();
	double va=acos(a.mx/a.abs());
	double vb=acos(b.mx/b.abs());
	return va<vb;
}
bool check(PT a,PT b,PT c){return (b-a).cross(c-b)>0;}
LL T(PT a,PT b,PT c){//return abs(a.mx*b.my+a.my*c.mx+b.mx*c.my-a.mx*c.my-a.my*b.mx-b.my*c.mx);
  LL d0=a.mx*b.my-a.mx*c.my;
  LL d1=a.my*c.mx-a.my*b.mx;
  LL d2=b.mx*c.my-b.my*c.mx;
	if((d0<=0 && d1>=0)||(d0>=0&&d1<=0))return abs(d0+d1+d2);
	if((d2<=0 && d1>=0)||(d2>=0&&d1<=0))return abs(d1+d2+d0);
	//if((d0<=0 && d2=>0)||(d0>=0&&d2<=0))
	return abs(d0+d2+d1);
}
LL T(ADT&con,int i,int j,int k){return T(con[i],con[j],con[k%con.size()]);}
LL BinSearch(ADT&con,int i,int j,int b,int e){
	if(e-b==0)return 0;
	if(e-b==1)return T(con,i,j,b);
	int m=(b+e)/2;
	LL a0=T(con,i,j,m-1);
	LL a1=T(con,i,j,m);
	if(a0>a1)return BinSearch(con,i,j,b,m);
	if(a0<a1)return BinSearch(con,i,j,m,e);
	return a0;
}
void maxDiameter(ADT&con){
  int n=con.size();
  for(int i=0;i<n;i++){
    LL M2=0;
    for(int j=0;j<n;j++){
      M2=max(M2,(con[i]-con[j]).abs2());
    }
    con[i].md=sqrt(M2);
  }
}
LL maxQuadrilateral2(ADT&con){
	LL M=0;
	int n=con.size();
	for(int i=0;i<n;i++){PT a=con[i];
		for(int j=i+1;j<n;j++){PT b=con[j];
			LL area1=BinSearch(con,i,j,i+1,j);
			LL area2=BinSearch(con,i,j,j+1,n+i);
			M=max(M,area1+area2);
			//M=max(M,area2);
		}
	}
	return M;
}
LL maxQuadrilateral2D(ADT&con){
  maxDiameter(con);
	LL M=0;
	int n=con.size();
	for(int i=0;i<n;i++){PT a=con[i];LL ad=a.md;
		for(int j=i+1;j<n;j++){PT b=con[j];LL bd=b.md;
      double d=(a-b).abs();
      if(min(ad+1,bd+1)*(d+1)<=M)continue;
			LL area1=BinSearch(con,i,j,i+1,j);
			LL area2=BinSearch(con,i,j,j+1,n+i);
			M=max(M,area1+area2);
			//M=max(M,area2);
		}
	}
	return M;
}
bool LESS(PT a,PT b){
	if(a.my!=b.my)return a.my<b.my;
	return a.mx>b.mx;
}
LL RAND(){return ((rand()*32768LL+rand())&0x7fffffff)%1000000000;}
void tdgen(LL N){
  cout<<1<<endl;
  cout<<N<<endl;
  for(LL k=0;k<N;k++){
    cout<<RAND()<<" "<<RAND()<<endl;
  }  
}
void genhull(ADT&pts,ADT&con){
	int n=pts.size();
	low=PT(0,INT_MAX);  
	for(int k=0;k<n;k++){if(LESS(pts[k],low))low=pts[k];}
	sort(pts.begin(),pts.end(),cmpangle);
	con.clear();
	for(int k=0;k<=n;k++){
		PT c=pts[k%n];
		if(con.size()<2){con.push_back(c);continue;}
		if(check(con[con.size()-2],con[con.size()-1],c)){
			con.push_back(c);
		}else{
			while((con.size()>=2)&&(check(con[con.size()-2],con[con.size()-1],c)==false)){
				con.pop_back();					
			}				
			con.push_back(c);
		}
	}
	con.pop_back();	
}

void genhull(LL n){srand(1);
  ADT pts(n);for(LL k=0;k<n;k++){pts[k].mx=RAND();pts[k].my=RAND();}
  ADT con;genhull(pts,con);
  random_shuffle(con.begin(),con.end());  
  cout<<1<<endl;
  cout<<con.size()<<endl;
  for(LL k=0;k<con.size();k++){
    cout<<con[k].mx<<" "<<con[k].my<<endl;
  }  
}
void gencircle(LL n){
  ADT pts(n);
  LL cx,cy,cr;cx=cy=500000000;cr=cx/10*9;
  double PI2=acos(-1)*2;
  for(LL k=0;k<n;k++){
    LL x,y;
    x=cx+cr*cos(PI2*k/n);
    y=cy+cr*sin(PI2*k/n);
    pts[k].mx=x;pts[k].my=y;
  }
  ADT con;genhull(pts,con);
  random_shuffle(con.begin(),con.end());  
  cout<<1<<endl;
  cout<<con.size()<<endl;
  for(LL k=0;k<con.size();k++){
    cout<<con[k].mx<<" "<<con[k].my<<endl;
  }    
}
void SolveT3(ADT&pts,ADT&con){
  if(con.size()<=2){cout<<0<<endl;return;}        //
  LL M=T(con[0],con[1],con[2]);                  
  for(int k=0;k<3;k++)pts.erase(find(pts.begin(),pts.end(),con[k]));// may duplicated 重複點 放入example 凹 平 放入 example
  LL m=M;
  for(int k=0;k<3;k++){
    PT a=con[k],b=con[(k+1)%3];
    for(int i=0;i<pts.size();i++){
      m=min(m,T(a,b,pts[i]));
    }  
  }
  LL ans=M-m;
  if(ans%2)cout<<ans/2<<".5"<<endl;
	else cout<<ans/2<<endl;	  
}
void Solve(){
	int n;cin>>n;
	while(cin>>n){
		ADT pts(n);
		for(int k=0;k<n;k++){cin>>pts[k];}
		ADT con;genhull(pts,con);
    if(con.size()<=3){SolveT3(pts,con);continue;}
		long long ans=maxQuadrilateral2(con);
		if(ans%2)cout<<ans/2<<".5"<<endl;
		else cout<<ans/2<<endl;	
	}
}
void SolveD(){
	int n;cin>>n;
	while(cin>>n){
		ADT pts(n);
		for(int k=0;k<n;k++){cin>>pts[k];}
		ADT con;genhull(pts,con);
    if(con.size()<=3){SolveT3(pts,con);continue;}
		long long ans=maxQuadrilateral2D(con);
		if(ans%2)cout<<ans/2<<".5"<<endl;
		else cout<<ans/2<<endl;	
	}
}

LL FOUR(PT a,PT b,PT c,PT d){
	return abs(
	+a.mx*b.my-b.mx*a.my
	+b.mx*c.my-c.mx*b.my
	+c.mx*d.my-d.mx*c.my
	+d.mx*a.my-a.mx*d.my
	);
}

void N3(){
	int n;cin>>n;
	while(cin>>n){
		ADT pts(n);
		for(int k=0;k<n;k++)cin>>pts[k];
	    LL ans=0;
		for(int i=0;i<n;i++){for(int j=i+1;j<n;j++){for(int k=j+1;k<n;k++){for(int u=k+1;u<n;u++){
			LL v;
			//if(ans<(v=FOUR(pts[i],pts[j],pts[k],pts[u])))cout<<i<<j<<k<<u<<" "<<v<<endl;
			//if(ans<(v=FOUR(pts[i],pts[j],pts[u],pts[k])))cout<<i<<j<<u<<k<<" "<<v<<endl;
			ans=max(ans,FOUR(pts[i],pts[j],pts[k],pts[u]));
			ans=max(ans,FOUR(pts[i],pts[j],pts[u],pts[k]));
			ans=max(ans,FOUR(pts[i],pts[k],pts[j],pts[u]));
		}}}}    
		if(ans%2)cout<<ans/2<<".5"<<endl;
		else cout<<ans/2<<endl;	
	}  
}

void M3(){
	int n;cin>>n;
	while(cin>>n){
		ADT pts(n);
		for(int k=0;k<n;k++){cin>>pts[k];}
		ADT con;genhull(pts,con);
    if(con.size()<=3){SolveT3(pts,con);continue;}  
		n=con.size();LL ans=0;
		for(int i=0;i<n;i++)for(int j=i+1;j<n;j++){
      LL M1=0,M2=0;
      for(int k=j+1;k<n+i;k++){M1=max(M1,T(con,i,j,k));}
      for(int k=i+1;k<j;k++)  {M2=max(M2,T(con,i,j,k));}
      ans=max(ans,M1+M2);
    }
		if(ans%2)cout<<ans/2<<".5"<<endl;
		else cout<<ans/2<<endl;	
	}  
}
int main(int argc,char**argv){
  if(argc==3){srand(time(0));
    if(string("tdgen")==argv[1]){
      tdgen(atoi(argv[2]));
    }
    if(string("genhull")==argv[1]){
      genhull(atoi(argv[2]));
    }
    if(string("gencircle")==argv[1]){
      gencircle(atoi(argv[2]));
    }
    return 0;
  }
  if(argc==2){
    if(string("N3")==argv[1]){
      N3();return 0;
    }
    if(string("M3")==argv[1]){
      M3();return 0;
    }
    if(string("ND")==argv[1]){
      Solve();return 0;
    }
    
  }
  SolveD();
	return 0;
}


