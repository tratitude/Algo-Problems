#include <bits/stdc++.h>
using namespace std;

int main() {
    int n;
    int a[55];
    cin >> n;
    assert(3 <= n && n <= 50);
    for (int i = 0; i < n; i++) cin >> a[i];
    assert(a[0] >= 1);
    assert(a[n-1] <= 100);
    for (int i = 1; i < n; i++) assert(a[i] >= a[i - 1]);
    for (int i = 1; i < n - 1; i++)
        if (a[i] != a[0]) {
            puts("no");
            return 0;
        }
    if (a[n - 1] % a[0] != 0) {
        puts("no");
        return 0;
    }
    puts("yes");
    return 0;
}