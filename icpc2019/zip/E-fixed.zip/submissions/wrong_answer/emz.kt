private fun nextLine() = readLine()!!
private fun nextInt() = nextLine().toInt()
private fun nextToks() = nextLine().split(" ")
private fun nextInts() = nextToks().map{it.toInt()}

fun solve() {
    val n = 1999
    val (k, l) = nextInts()
	if (l > n) {
		println(-1)
		return
	}
    var goal = k + n
    var a = IntArray(n)
    a[0] = -1
    for (i in 1 until n-1) {
        a[i] = minOf(goal, 1_000_000_000)
        goal -= a[i]
    }
    a[n-1] = goal
    println(n)
    println(a.joinToString(" "))
}

fun main() = (1..nextInt()).forEach{solve()}
