import java.util.ArrayList;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner cin = new Scanner(System.in);

		int n = cin.nextInt();
		
		int[][] op = {
				{1, 1, 3, 3, 0},
				{2, 2, 4, 4, 1},
				{2, 2, 2, 2, 2},
				{4, 4, 3, 3, 3},
				{2, 2, 4, 4, 4}
		};
		
		ArrayList<Integer> PDS = new ArrayList<Integer>();
		int[] L = new int[n+1];
		int[] parent = new int[n+1];
		int[] degree = new int[n+1];
		
		for (int i=0; i<n-1; i++)
		{
			int u = cin.nextInt();
			int v = cin.nextInt();
			parent[v>u?v:u] = u<v?u:v;
			degree[u]++;
			degree[v]++;
		}
		
		for (int i=n; i>=2; i--)
		{
			if (L[i] == 2)
			{
				PDS.add(i);
			}
			L[parent[i]] = op[L[parent[i]]][L[i]];
		}
		
		if (L[1] <= 2)
		{
			PDS.add(1);
		}
		
		System.out.println(PDS.size());
		
		cin.close();
	}
}
