import java.math.BigInteger

private fun nextLine() = readLine()!!
private fun nextInt() = nextLine().toInt()
private fun nextToks() = nextLine().split(" ").filter{it!=""}
private fun nextInts() = nextToks().map{it.toInt()}

fun sol() {
    val (n, m) = nextInts()
    var s = (1..m).map{BigInteger(nextLine(),2)}
    var ans = (1 until (1 shl m)).filter{pat ->
        val cand = (0 until m).filter{(1 shl it).and(pat)>0}.map{s[it]}
        if (cand.size>0)
            cand.reduce{x: BigInteger, y: BigInteger ->
                x.or(y)
            }==(1.toBigInteger().shl(n)-1.toBigInteger())
        else false
    }.map{java.lang.Integer.bitCount(it)}.min()?:-1
    println("$ans")
}

fun main() = (1..nextInt()).forEach{sol()}
