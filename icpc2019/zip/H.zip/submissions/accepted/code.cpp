#include <iostream>
#include <cassert>
using namespace std;
typedef unsigned long long uLL;

int main()
{
unsigned int kase, k, n;

    cin >> kase;
    for (k=1;  k<=kase; k++) {
        uLL a=0, b, c;
        cin >> n;
        assert((1<=n) && (n<=1e7));
        for (b=n+1; b<=n+n; ++b)
            if ((b*n) % (b-n)==0) {
                c=(b*n)/(b-n);
                if (a<(c ^ b))
                    a=c ^ b;
            }
        // the answer should be equal to (uLL)n*(n+1) ^ (n+1), in this case b=(n+1) and c=n*(n+1)
        assert(a==(uLL)n*(n+1) ^ (n+1));
        cout << a << endl;
    }
    return 0;
}
