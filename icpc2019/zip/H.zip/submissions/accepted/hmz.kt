private fun nextLine() = readLine()!!
private fun nextInt() = nextLine().toInt()
private fun nextLong() = nextLine().toLong()

fun f(n: Long): Long {
    var ret = 0L
    for (b in n+1..2*n) {
        val num = n * b
        if (num % (b-n) == 0L)
            ret = maxOf(ret, (num / (b-n)) xor b)
        if (num / (b-n) + b < ret) break
    }
    return ret
}

fun main() = (1..nextInt()).forEach{println(f(nextLong()))}
