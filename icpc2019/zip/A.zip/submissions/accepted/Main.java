import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class Main
{
	static int numVehicles;
	static int sizeOfRed;
	static int THRESHOLD = 10;
	static int FORWARD = 1, DOWNWARD = 1;
	static int BACKWARD = -1, UPWARD = -1;
	
	public static void main(String[] args)
	{
		Scanner cin = new Scanner(System.in);
		HashSet<String> visitedBoard;
		Queue<Node> queue;
		Node root;
		Boolean found = false;
		
		int[][] bitBoard;
		
		sizeOfRed = 0;
		numVehicles = 0;
		bitBoard = new int[6][6];
		
		for (int i=0; i<6; i++)
		{
			for (int j=0; j<6; j++)
			{
				bitBoard[i][j] = cin.nextInt();
				
				if (bitBoard[i][j] == 1)
				{
					sizeOfRed++;
				}
				
				if (bitBoard[i][j] > numVehicles)
				{
					numVehicles = bitBoard[i][j];
				}
			}
		}

		root = new Node(0,null,new Board(bitBoard));
		visitedBoard = new HashSet<String>();			
		visitedBoard.add(root.boardToString());

		queue = new LinkedList<Node>();
		queue.add(root);
		
L:		while (queue.size() != 0)
		{
			Node node = queue.poll();
			node.decideChildren(visitedBoard);
			
			if (node.children.size() > 0)
			{
				for (Node n : node.children)
				{
					if (n.isGoalBoard())
					{
						System.out.println(n.level+sizeOfRed);
						found = true;
						break L;
					}
					queue.add(n);
				}
			}
		}
		
		if (!found)
		{
			System.out.println(-1);
		}
			
		cin.close();
	}
}

class Point
{
	int y, x;
	
	Point(int y, int x)
	{
		this.y = y;		
		this.x = x;
	}
	
	Point clonePoint()
	{
		return new Point(x,y);
	}
}

class Vehicle
{
	int id, size;
	ArrayList<Point> positions;
	boolean HorV;
	
	Vehicle(int id)
	{
		positions = new ArrayList<Point>();
		this.id = id;
		HorV = false;
	}
	
	void decideHorV()
	{
		if (positions.get(0).y == positions.get(1).y)
		{
			HorV = true;
		}
	}
	
	Vehicle cloneVehicle()
	{
		Vehicle newV =  new Vehicle(id);
		newV.size = size;
		newV.HorV = HorV;
		
		ArrayList<Point> newP = new ArrayList<Point>();
		for (Point p : positions)
		{
			newP.add(p.clonePoint());
		}
		
		return newV;
	}
}

class Board
{
	int[][] bitBoard;
	Vehicle[] vehicles;
	
	Board(int[][] b)
	{
		vehicles = new Vehicle[Main.numVehicles+1];
		for(int i=1; i<=Main.numVehicles; i++)
		{
			vehicles[i] = new Vehicle(i);
		}

		bitBoard = new int[6][6];
		for (int i=0; i<6; i++)
		{
			for (int j=0; j<6; j++)
			{
				if (b[i][j] > 0)
				{
					bitBoard[i][j] = b[i][j];
					Point p = new Point(i,j);
					vehicles[bitBoard[i][j]].positions.add(p);
					vehicles[bitBoard[i][j]].size++;
				}
			}
		}
		
		for (int i=1; i<=Main.numVehicles; i++)
		{
			vehicles[i].decideHorV();
		}
	}
	
	void makeMove(int dir, Vehicle v)
	{
		if (v.HorV)
		{
			if (dir == Main.FORWARD)
			{
				moveForward(v);
			}
			else
			{
				moveBackward(v);
			}
		}
		else
		{
			if (dir == Main.UPWARD)
			{
				moveUpward(v);
			}
			else
			{
				moveDownward(v);
			}
		}
	}
	
	void moveForward(Vehicle v)
	{
		bitBoard[v.positions.get(0).y][v.positions.get(0).x] = 0;
		bitBoard[v.positions.get(v.size-1).y][v.positions.get(v.size-1).x+1] = v.id;
		
		for (int i=0; i<v.size-1; i++)
		{
			v.positions.get(i).y = v.positions.get(i+1).y;
			v.positions.get(i).x = v.positions.get(i+1).x;
		}
		
		v.positions.get(v.size-1).x = v.positions.get(v.size-1).x+1;
	}
	
	void moveBackward(Vehicle v)
	{
		bitBoard[v.positions.get(0).y][v.positions.get(0).x-1] = v.id;
		bitBoard[v.positions.get(v.size-1).y][v.positions.get(v.size-1).x] = 0;
		
		for (int i=v.size-2; i>=0; i--)
		{
			v.positions.get(i+1).y = v.positions.get(i).y;
			v.positions.get(i+1).x = v.positions.get(i).x;
		}
		
		v.positions.get(0).x = v.positions.get(0).x-1;
	}
	
	void moveUpward(Vehicle v)
	{
		bitBoard[v.positions.get(0).y-1][v.positions.get(0).x] = v.id;
		bitBoard[v.positions.get(v.size-1).y][v.positions.get(v.size-1).x] = 0;
		
		for (int i=v.size-2; i>=0; i--)
		{
			v.positions.get(i+1).y = v.positions.get(i).y;
			v.positions.get(i+1).x = v.positions.get(i).x;
		}
		
		v.positions.get(0).y = v.positions.get(0).y-1;
	}
	
	void moveDownward(Vehicle v)
	{
		bitBoard[v.positions.get(0).y][v.positions.get(0).x] = 0;
		bitBoard[v.positions.get(v.size-1).y+1][v.positions.get(v.size-1).x] = v.id;
		
		for (int i=0; i<v.size-1; i++)
		{
			v.positions.get(i).y = v.positions.get(i+1).y;
			v.positions.get(i).x = v.positions.get(i+1).x;
		}
		
		v.positions.get(v.size-1).y = v.positions.get(v.size-1).y+1;
	}

	boolean isMoveLegal(Vehicle v, int dir)
	{
		if (v.HorV)
		{
			if (dir == Main.FORWARD)
			{
				if (v.positions.get(v.size-1).x+1 <= 5 && bitBoard[v.positions.get(v.size-1).y][v.positions.get(v.size-1).x+1] == 0)
				{
					return true;
				}
			}
			else
			{
				if (v.positions.get(0).x-1 >= 0 && bitBoard[v.positions.get(0).y][v.positions.get(0).x-1] == 0)
				{
					return true;
				}
			}
		}
		else
		{
			if (dir == Main.UPWARD)
			{
				if (v.positions.get(0).y-1 >= 0 && bitBoard[v.positions.get(0).y-1][v.positions.get(0).x] == 0)
				{
					return true;
				}
			}
			else
			{
				if (v.positions.get(v.size-1).y+1 <= 5 && bitBoard[v.positions.get(v.size-1).y+1][v.positions.get(v.size-1).x] == 0)
				{
					return true;
				}
			}
		}

		return false;
	}

	Board cloneBoard()
	{
		Board newB = new Board(bitBoard);
		
		return newB;
	}
}

class Node
{
	int level;
	Board board;
	Node parent;
	ArrayList<Node> children;
	
	Node(int level, Node p, Board b)
	{
		this.level = level;
		this.board = b;	
		this.parent = p;
		this.children = new ArrayList<Node>();
	}
	
	void decideChildren(HashSet<String> visitedBoard)
	{
		for (int i=1; i<=Main.numVehicles; i++)
		{
			if (board.isMoveLegal(board.vehicles[i], 1))
			{
				Node child = new Node(level+1, this, board.cloneBoard());
				child.board.makeMove(1, child.board.vehicles[i]);
				String boardString = child.boardToString();
				if (!visitedBoard.contains(boardString))
				{
					if (child.level + (6 - child.board.vehicles[1].positions.get(0).x) <= Main.THRESHOLD)
					{
						children.add(child);
					}
				}
			}
			
			if (board.isMoveLegal(board.vehicles[i], -1))
			{
				Node child = new Node(level+1, this, board.cloneBoard());
				child.board.makeMove(-1, child.board.vehicles[i]);
				String boardString = child.boardToString();
				if (!visitedBoard.contains(boardString))
				{
					if (child.level + (6 - child.board.vehicles[1].positions.get(0).x) <= Main.THRESHOLD)
					{
						children.add(child);
					}
				}
			}
		}
	}
	
	String boardToString()
	{
		String result = "";
		
		for (int i=0; i<6; i++)
		{
			for (int j=0; j<6; j++)
			{
				result = result + board.bitBoard[i][j];
			}
		}
		
		return result;
	}
	
	boolean isGoalBoard()
	{
		for (int i=5; i>=6-Main.sizeOfRed; i--)
		{
			if (board.bitBoard[2][i] != 1)
			{
				return false;
			}
		}

		return true;
	}
}