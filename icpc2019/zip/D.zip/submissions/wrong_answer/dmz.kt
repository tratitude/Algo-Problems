fun main() = println(readLine()!!.split(" ").filter{it != "" && it != "bubble" && it != "tapioka"}.joinToString(" "))
