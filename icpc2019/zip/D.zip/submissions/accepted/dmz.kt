fun main() {
    val ans = readLine()!!.split(" ").filter{it != "" && it != "bubble" && it != "tapioka"}.joinToString(" ")
    println(if (ans.length==0) "nothing" else ans)
}
