#include <bits/stdc++.h>
using namespace std;

int main() {
  string ans;
  for(int i = 0; i < 3; i++) {
    string x;
    cin >> x;
    if (x != "bubble" && x != "tapioka")
      ans += " " + x;
  }
  if (ans == "") ans = " nothing";
  cout << ans.substr(1) << endl;
  return 0;
}