
#include <iostream>
#include <bitset>

using namespace std;

#define MAX 8

int convert2index(bitset<MAX> src[MAX], int n){
	
	bitset<MAX> s[MAX];

	for(int i=0; i<n; ++i){
		s[i] = src[i];
	}

	int order[MAX];
	bitset<MAX> found; found.reset();

	for(int i=0; i<n; ++i){
		for(int j=0; j<n; ++j){
			if(!found[j] && s[j].count() == 0){
				found[j] = 1;
				order[i] = j;
				for(int k=0; k<n; ++k){
					s[k][j] = 0;
				}
				break;
			}
		}
	}

	int ret = 0;

	for(int i=1; i<n; ++i){
		for(int j=0; j<i; ++j){
			ret = ret*2 + src[order[i]][order[j]];
		}
	}

	return ret;
}

char *dp_table;

int sch(bitset<MAX> src[MAX], bitset<MAX> dst[MAX], int n, int k){
		
	int index = convert2index(src, n);

	if(dp_table[index] >= 0){
		return dp_table[index];
	}

	for(int i=0; i<n; ++i){
		if(src[i].count() == k-1 && dst[i].count() == n-k){
			return dp_table[index] = 0;
		}
	}

	int best = 1000;

	bitset<MAX> src2[MAX];
	bitset<MAX> dst2[MAX];

	for(int i=0; i<n; ++i){
		for(int j=i+1; j<n; ++j){
			if(!dst[i][j] && !dst[j][i]){
				
				// i ---> j
				for(int k=0; k<n; ++k){
					src2[k] = src[k];
					dst2[k] = dst[k];
				}
				src2[j][i] = dst2[i][j] = 1;
				dst2[i] |= dst2[j];
				src2[j] |= src2[i];
				for(int k=0; k<n; ++k){
					if(src2[i][k]){
						dst2[k] |= dst2[i];
					}
					if(dst2[j][k]){
						src2[k] |= src2[j];
					}
				}

				int ret1 = sch(src2, dst2, n, k) + 1;

				// j ---> i 
				
				for(int k=0; k<n; ++k){
					src2[k] = src[k];
					dst2[k] = dst[k];
				}
				src2[i][j] = dst2[j][i] = 1;
				dst2[j] |= dst2[i];
				src2[i] |= src2[j];
				for(int k=0; k<n; ++k){
					if(src2[j][k]){
						dst2[k] |= dst2[j];
					}
					if(dst2[i][k]){
						src2[k] |= src2[i];
					}
				}

				int ret2 = sch(src2, dst2, n, k) + 1;

				if(best > max(ret1, ret2)){
					best = max(ret1, ret2);
				}
			}
		}
	}
	
	return dp_table[index] = best;
}

int main(){
	
	int n, k, r;

	cin >> n >> k >> r;

	dp_table = new char [1u << (n*(n-1)/2)];
	
	for(int i=0; i<(1u << (n*(n-1)/2)); ++i){
			dp_table[i] = -1;
	}

	bitset<MAX> src[MAX], dst[MAX];

	for(int i=0; i<n; ++i){
		src[i].reset();
		dst[i].reset();
	}

	for(int i=0; i<r; ++i){
		int a, b; cin >> a >> b;
		src[b][a] = dst[a][b] = 1;
		src[b] |= src[a]; 
		dst[a] |= dst[b];
		for(int k=0; k<n; ++k){
			if(dst[b][k]){
				src[k] |= src[b];
			}
			if(src[a][k]){
				dst[k] |= dst[a];
			}
		}
	}
	
	cout << sch(src, dst, n, k) << endl;

	return 0;
}
