private fun nextLine() = readLine()!!
private fun nextToks() = nextLine().split(" ")
private fun nextInts() = nextToks().map{it.toInt()}

val MAX = 8
var table = ByteArray(1 shl 28){-1}
var lookup = IntArray(256){java.lang.Integer.bitCount(it)}

operator fun Int.get(i: Int) = this.shr(i).and(1)==1
// not really set. You must use x = x.set(5)
fun Int.set(i: Int, v: Int = 1) = this.and(1.shl(i).inv()).or(v.shl(i))
fun Int.count() = java.lang.Integer.bitCount(this)
// fun Int.count() = lookup[this]

var s = IntArray(MAX)
var order = IntArray(MAX)

fun convert2index(src: IntArray, dst: IntArray, n: Int): Int {
	// var s = src.clone() // a clone of src, a bitset array
    for (i in 0 until MAX) s[i] = src[i]
    // var order = IntArray(n){it} // an int array of {0, 1, ..., n-1}
    for (i in 0 until MAX) order[i] = i

	for (i in 0 until n) { 
		var first = true
        for (j in i until n) {
            if (s[order[j]].count() == 0) {
                if (first) {
                    val swap = order[i]
                    order[i] = order[j]
                    order[j] = swap
                }
                else if (dst[order[j]].count() > dst[order[i]].count()) {
                    val swap = order[i]
                    order[i] = order[j]
                    order[j] = swap
                }
			}
		}
		for (j in i+1 until n)
			s[order[j]] = s[order[j]].set(order[i],0)
	}
	
	var ret = 0

	for(i in 1 until n)
		for(j in 0 until i)
			ret = ret*2 + (if (src[order[i]][order[j]]) 1 else 0)

	return ret
}

var depth = 0
var src2pool = List<IntArray>(64){IntArray(MAX)}
var dst2pool = List<IntArray>(64){IntArray(MAX)}

fun sch(src: IntArray, dst: IntArray, n: Int, k: Int): Int {
    var index = convert2index(src, dst, n)
    if (table[index] >= 0) return table[index].toInt()

    for (i in 0 until n)
        if (src[i].count() == k-1 && dst[i].count() == n-k) {
            table[index] = 0
            return 0
        }

    val src2 = src2pool[depth]
    val dst2 = dst2pool[depth]
    depth += 1
    var best = 100

    for (i in 0 until n) {
        for (j in i+1 until n) {
            if(!dst[i][j] && !dst[j][i]) {
                // i ----> j
                for (p in 0 until n) {
                    src2[p] = src[p]
                    dst2[p] = dst[p]
                }
                src2[j] = src2[j].set(i)
                dst2[i] = dst2[i].set(j)
                dst2[i] = dst2[i] or dst2[j]
                src2[j] = src2[j] or src2[i]
                for (p in 0 until n) {
                    if (src2[i][p]) dst2[p] = dst2[p] or dst2[i]
                    if (dst2[j][p]) src2[p] = src2[p] or src2[j]
                }
                val ret1 = sch(src2, dst2, n, k) + 1

                // j ----> i
                for (p in 0 until n) {
                    src2[p] = src[p]
                    dst2[p] = dst[p]
                }
                src2[i] = src2[i].set(j)
                dst2[j] = dst2[j].set(i)
                dst2[j] = dst2[j] or dst2[i]
                src2[i] = src2[i] or src2[j]
                for (p in 0 until n) {
                    if (src2[j][p]) dst2[p] = dst2[p] or dst2[j]
                    if (dst2[i][p]) src2[p] = src2[p] or src2[i]
                }
                val ret2 = sch(src2, dst2, n, k) + 1

                best = minOf(best, maxOf(ret1, ret2))
            }
        }
    }
    depth -= 1
    table[index] = best.toByte()
    return best 
}

fun main() {
    val (n, k, r) = nextInts()
    var src = IntArray(MAX){0}
    var dst = IntArray(MAX){0}

    if (n == 8 && r <= 1) {
        val ans = listOf(0,7,9,11,12,12,11,9,7)
        println("${ans[k]-r}")
    }
    else if (n==8 && r == 2) {
        val (a, b) = nextInts()
        val (c, d) = nextInts()
        if (a != c && a != d && b != c && b != d) { // 2 parallel
            val ans = listOf(0,5,7,9,10,10,9,7,5)
            println("${ans[k]}")
        }
        else if (b == c || d == a) { // *->*->*
            val ans = listOf(0,5,7,9,10,10,9,7,5)
            println("${ans[k]}")
        }
        else if (a == c) { // branch
            val ans = listOf(0,5,8,9,11,11,10,8,6)
            println("${ans[k]}")
        }
        else if (b == d) { // merge
            val ans = listOf(0,6,8,10,11,11,9,8,5)
            println("${ans[k]}")
        }
    }
    else {
        for (rnd in 1..r) {
            val (a, b) = nextInts()
            src[b] = src[b].set(a)
            dst[a] = dst[a].set(b)
            src[b] = src[b] or src[a]
            dst[a] = dst[a] or dst[b]
            for (i in 0 until n) {
                if (dst[b][i])
                    src[i] = src[i] or src[b]
                if (src[a][i])
                    dst[i] = dst[i] or dst[a]
            }
        }
        println(sch(src, dst, n, k))
    }
}
