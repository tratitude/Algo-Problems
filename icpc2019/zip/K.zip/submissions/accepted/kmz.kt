import java.util.PriorityQueue

private fun nextLine() = readLine()!!
private fun nextInt() = nextLine().toInt()
private fun nextToks() = nextLine().split(" ").filter{it!=""}
private fun nextInts() = nextToks().map{it.toInt()}

fun sol() {
    val n = nextInt()
    var pq = PriorityQueue<Int>(nextInts())
    var ans = 0
    while (pq.size > 1) {
        val x = pq.poll()
        val y = pq.poll()
        ans += x + y
        pq.add(x + y)
    }
    println("$ans")
}

fun main() = (1..nextInt()).forEach{sol()}
