#include<queue>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<fstream>
#include<iostream>
using namespace std;
const int inf=100010;

int n;
priority_queue<int,vector<int>,greater<int> > q;

int main()
{
    int cases;
    scanf("%d",&cases);
    while(cases--){
        scanf("%d",&n);
        for(int i=1,x;i<=n;i++)
        {
            scanf("%d",&x);
            q.push(x);
        }
        int ans=0;
        for(int i=1;i<n;i++)
        {
            int t1=q.top();q.pop();
            int t2=q.top();q.pop();
            ans+=t1+t2;
            q.push(t1+t2);
        }
        cout << ans << endl;
        q.pop();
    }
    return 0;
}
